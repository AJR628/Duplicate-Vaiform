import { Router } from 'express';
import { z } from 'zod';
import requireAuth from '../middleware/requireAuth.js';
import { enforceCreditsForRender } from '../middleware/planGuards.js';
import { spendCredits, refundCredits, RENDER_CREDIT_COST } from '../services/credit.service.js';
import {
  startStudio,
  getStudio,
  generateQuoteCandidates,
  generateImageCandidates,
  chooseCandidate,
  finalizeStudio,
  listStudios,
  deleteStudio,
  generateVideoCandidates,
  finalizeStudioMulti,
  createRemix,
  listRemixes,
  generateSocialImage,
  generateCaption,
} from '../services/studio.service.js';
import crypto from 'node:crypto';
import { bus, sendEvent } from '../utils/events.js';
import { resolveStockVideo } from '../services/stock.video.provider.js';
import { dump as storeDump, get as storeGet } from '../studio/store.js';
import { ensureStudio } from '../studio/ensure.js';
import { withRenderSlot } from '../utils/render.semaphore.js';

const r = Router();
r.use(requireAuth);

// Apply ensureStudio middleware for critical POST endpoints

const StartSchema = z.object({
  template: z.enum(['calm', 'bold', 'cosmic', 'minimal']),
  durationSec: z.number().int().min(6).max(10),
  maxRefines: z.number().int().min(0).max(10).optional(),
  debugExpire: z.boolean().optional(),
});

const QuoteSchema = z.object({
  studioId: z.string().min(3),
  mode: z.enum(['quote', 'feeling']),
  text: z.string().min(2).max(280),
  count: z.number().int().min(1).max(5).optional(),
});

const ImageSchema = z.object({
  studioId: z.string().min(3),
  kind: z.enum(['stock', 'imageUrl', 'upload', 'ai']),
  query: z.string().optional(),
  imageUrl: z.string().url().optional(),
  uploadUrl: z.string().url().optional(),
  prompt: z.string().optional(),
  kenBurns: z.enum(['in', 'out']).optional(),
});

const VideoSchema = z.object({
  studioId: z.string().min(3),
  kind: z.enum(['stockVideo']).default('stockVideo'),
  query: z.string().min(1),
});

const ChooseSchema = z.object({
  studioId: z.string().min(3),
  track: z.enum(['quote', 'image', 'video']),
  candidateId: z.string().min(3),
});

const FinalizeSchema = z.object({
  studioId: z.string().min(3),
  voiceover: z.boolean().optional(),
  wantAttribution: z.boolean().optional(),
  captionMode: z.enum(['progress', 'karaoke']).optional(),
  // New multi-format payload
  renderSpec: z.any().optional(),
  formats: z.array(z.enum(['9x16', '1x1', '16x9']).default('9x16')).optional(),
  wantImage: z.boolean().optional(),
  wantAudio: z.boolean().optional(),
});

r.post('/start', async (req, res) => {
  const parsed = StartSchema.safeParse(req.body || {});
  if (!parsed.success)
    return res
      .status(400)
      .json({ success: false, error: 'INVALID_INPUT', detail: parsed.error.flatten() });
  const { template, durationSec, maxRefines = 5, debugExpire = false } = parsed.data;
  try {
    const s = await startStudio({
      uid: req.user.uid,
      template,
      durationSec,
      maxRefines,
      debugExpire,
    });
    return res.json({ success: true, data: s });
  } catch (e) {
    return res.status(500).json({ success: false, error: 'STUDIO_START_FAILED' });
  }
});

r.post('/video', ensureStudio(true), async (req, res) => {
  const parsed = VideoSchema.safeParse(req.body || {});
  if (!parsed.success)
    return res
      .status(400)
      .json({ success: false, error: 'INVALID_INPUT', detail: parsed.error.flatten() });
  const { studioId, kind, query } = parsed.data;
  try {
    const v = await generateVideoCandidates({
      uid: req.user.uid,
      studioId,
      kind,
      query,
      targetDur: 8,
    });
    return res.json({ success: true, data: { video: v } });
  } catch (e) {
    return res.status(500).json({ success: false, error: 'STUDIO_VIDEO_FAILED' });
  }
});

r.post('/quote', ensureStudio(true), async (req, res) => {
  const t0 = Date.now();
  try {
    const parsed = QuoteSchema.safeParse(req.body || {});
    if (!parsed.success) {
      return res.json({
        success: false,
        error: 'BAD_REQUEST',
        detail: 'missing or invalid fields',
      });
    }
    const { studioId, mode, text, count = 3 } = parsed.data;
    const uid = req.user?.uid || 'anon';

    try {
      // Ensure studio exists (auto-create if missing) and set status
      // req.studioId guaranteed by middleware

      const q = await generateQuoteCandidates({
        uid,
        studioId,
        mode,
        text,
        template: undefined,
        count,
      });
      // status tracking can be added via store.touch if needed
      const ms = Date.now() - t0;
      const okLog = {
        studioId,
        ms,
        provider: process.env.QUOTES_PROVIDER || 'curated/local',
        model: null,
        charsOut: (q?.candidates?.[0]?.text || '').length,
        promptHash: crypto
          .createHash('sha1')
          .update(String(text || ''))
          .digest('hex')
          .slice(0, 8),
      };
      console.log('[quote][ok]', JSON.stringify(okLog));
      return res.json({ success: true, studioId, data: { quote: q } });
    } catch (e) {
      const ms = Date.now() - t0;
      const errObj = {
        studioId,
        ms,
        provider: process.env.QUOTES_PROVIDER || 'curated/local',
        model: null,
        code: e?.code || 'GEN_FAILED',
        message: e?.message || String(e),
        stackTop: (e?.stack || '').split('\n')[0],
      };
      console.error('[quote][err]', JSON.stringify(errObj));
      return res.json({
        success: false,
        error: 'STUDIO_QUOTE_FAILED',
        detail: e?.message || 'quote failed',
        cause: e?.code || 'GEN_FAILED',
      });
    }
  } catch (e) {
    const ms = Date.now() - t0;
    const errObj = {
      studioId: req.body?.studioId || null,
      ms,
      provider: process.env.QUOTES_PROVIDER || 'curated/local',
      model: null,
      code: 'ROUTE_FAIL',
      message: e?.message || String(e),
      stackTop: (e?.stack || '').split('\n')[0],
    };
    console.error('[quote][err]', JSON.stringify(errObj));
    return res.json({
      success: false,
      error: 'STUDIO_QUOTE_FAILED',
      detail: e?.message || 'route failed',
      cause: 'ROUTE_FAIL',
    });
  }
});

// Debug: quick ping for provider state
r.get('/dev/quote/ping', async (_req, res) => {
  const provider = process.env.QUOTES_PROVIDER || 'openai';
  const hasOpenAI = !!process.env.OPENAI_API_KEY;
  console.log('[dev][quote] provider', provider, 'OPENAI_API_KEY', hasOpenAI ? 'set' : 'missing');
  return res.json({ ok: true, provider, hasKey: hasOpenAI });
});

r.post('/image', ensureStudio(true), async (req, res) => {
  const parsed = ImageSchema.safeParse(req.body || {});
  if (!parsed.success)
    return res
      .status(400)
      .json({ success: false, error: 'INVALID_INPUT', detail: parsed.error.flatten() });
  const { studioId, kind, query, imageUrl, uploadUrl, prompt, kenBurns } = parsed.data;
  try {
    const q = await generateImageCandidates({
      uid: req.user.uid,
      studioId,
      kind,
      query: imageUrl || query,
      uploadUrl,
      prompt,
      kenBurns,
      count: 3,
    });
    return res.json({ success: true, data: { image: q } });
  } catch (e) {
    return res.status(500).json({ success: false, error: 'STUDIO_IMAGE_FAILED' });
  }
});

r.post('/choose', ensureStudio(true), async (req, res) => {
  const parsed = ChooseSchema.safeParse(req.body || {});
  if (!parsed.success)
    return res
      .status(400)
      .json({ success: false, error: 'INVALID_INPUT', detail: parsed.error.flatten() });
  const { studioId, track, candidateId } = parsed.data;
  try {
    console.log('studio.choose', { studioId, track, candidateId });
    const out = await chooseCandidate({ uid: req.user.uid, studioId, track, candidateId });
    return res.json({ success: true, data: out });
  } catch (e) {
    return res.status(500).json({ success: false, error: 'STUDIO_CHOOSE_FAILED' });
  }
});

r.post('/finalize', ensureStudio(true), enforceCreditsForRender(), async (req, res) => {
  const parsed = FinalizeSchema.safeParse(req.body || {});
  if (!parsed.success)
    return res
      .status(400)
      .json({ success: false, error: 'INVALID_INPUT', detail: parsed.error.flatten() });
  const {
    studioId,
    voiceover = false,
    wantAttribution = true,
    captionMode = 'progress',
    renderSpec,
    formats,
    wantImage = true,
    wantAudio = true,
  } = parsed.data;
  try {
    if (!renderSpec && !formats && !wantImage && !wantAudio) {
      // Back-compat: old finalize single format path
      const out = await withRenderSlot(() =>
        finalizeStudio({ uid: req.user.uid, studioId, voiceover, wantAttribution, captionMode })
      );
      return res.json({ success: true, data: out });
    }
    // New path: multi-format → run and emit events via bus, return JSON fallback
    // NOTE: This blocks the HTTP request until render completes (synchronous operation).
    // Server timeout is set to 15 minutes to accommodate long renders. For scalability,
    // background job queue is planned (P2).
    const out = await withRenderSlot(() =>
      finalizeStudioMulti({
        uid: req.user.uid,
        studioId,
        renderSpec: renderSpec || {},
        formats: formats || ['9x16', '1x1', '16x9'],
        wantImage,
        wantAudio,
        voiceover,
        wantAttribution,
        onProgress: (e) => sendEvent(studioId, e.event || 'progress', e),
      })
    );
    // Choose preferred URL (vertical if present)
    const urls = out?.urls || {};
    const publicUrl =
      urls[`${out.renderId}_9x16.mp4`] ||
      urls[`${out.renderId}_1x1.mp4`] ||
      urls[`${out.renderId}_16x9.mp4`] ||
      Object.values(urls)[0];
    sendEvent(studioId, 'video_ready', {
      url: publicUrl,
      durationSec: renderSpec?.output?.durationSec || undefined,
    });
    sendEvent(studioId, 'done', { url: publicUrl });
    console.log('[studio][finalize] emitted: video_ready, done');

    // Spend credits only if render succeeded (multi-format path)
    // Note: old path (finalizeStudio) spends credits in createShortService
    let creditsSpent = false;
    if (publicUrl || Object.keys(urls).length > 0) {
      try {
        await spendCredits(req.user.uid, RENDER_CREDIT_COST);
        creditsSpent = true;
      } catch (err) {
        console.error('[studio][finalize] Failed to spend credits:', err);
        // Don't fail the request - credits were already checked by middleware
      }
    }

    try {
      return res.json({
        success: true,
        url: publicUrl,
        durationSec: renderSpec?.output?.durationSec || undefined,
        urls,
        shortId: out?.shortId,
        thumbUrl: out?.thumbUrl,
      });
    } catch (err) {
      // If response failed after credits were spent, refund defensively
      if (creditsSpent && !res.headersSent) {
        try {
          await refundCredits(req.user.uid, RENDER_CREDIT_COST);
          console.log('[studio][finalize] Refunded credits after response failure');
        } catch (refundErr) {
          console.error(
            '[studio][finalize] Failed to refund credits after response failure:',
            refundErr
          );
        }
      }
      throw err; // Re-throw so outer catch handles it
    }
  } catch (e) {
    if (res.headersSent) return;
    if (e?.code === 'SERVER_BUSY' || e?.message === 'SERVER_BUSY') {
      res.set('Retry-After', '30');
      return res.status(503).json({ success: false, error: 'SERVER_BUSY', retryAfter: 30 });
    }
    if (e?.message === 'NEED_IMAGE_OR_VIDEO') {
      return res.status(400).json({ success: false, error: 'IMAGE_OR_VIDEO_REQUIRED' });
    }
    if (e?.message === 'VIDEO_SIZE') {
      return res.status(400).json({
        success: false,
        error: 'VIDEO_TOO_LARGE',
        hint: 'Try a shorter clip or a different source. Max bytes configurable via VIDEO_MAX_BYTES.',
      });
    }
    if (e?.message === 'RENDER_FAILED' || e?.message === 'FILTER_SANITIZE_FAILED') {
      return res.status(400).json({
        success: false,
        error: 'RENDER_FAILED',
        detail: e?.detail || e?.cause?.message || 'ffmpeg failed',
        filter: e?.filter,
      });
    }
    try {
      sendEvent(req.body?.studioId, 'error', { message: e?.message || 'FINALIZE_FAILED' });
    } catch {}
    return res.status(500).json({
      success: false,
      error: 'STUDIO_FINALIZE_FAILED',
      message: e?.message || 'Finalize failed',
    });
  }
});

// Server-Sent Events for Studio progress
r.get('/events/:studioId', async (req, res) => {
  const studioId = String(req.params?.studioId || '').trim();
  if (!studioId) return res.status(400).end();
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Connection', 'keep-alive');
  const handler = (payload) => {
    try {
      res.write(`data: ${JSON.stringify(payload)}\n\n`);
    } catch {}
  };
  bus.on(studioId, handler);
  req.on('close', () => bus.off(studioId, handler));
});

// --- Remix endpoints ---
const RemixSchema = z.object({
  parentRenderId: z.string().min(6),
  renderSpec: z.any(),
  formats: z.array(z.enum(['9x16', '1x1', '16x9']).default('9x16')).optional(),
  wantImage: z.boolean().optional(),
  wantAudio: z.boolean().optional(),
});

r.post('/remix', async (req, res) => {
  const parsed = RemixSchema.safeParse(req.body || {});
  if (!parsed.success)
    return res
      .status(400)
      .json({ success: false, error: 'INVALID_INPUT', detail: parsed.error.flatten() });
  const { parentRenderId, renderSpec, formats, wantImage = true, wantAudio = true } = parsed.data;
  try {
    const out = await createRemix({
      uid: req.user.uid,
      parentRenderId,
      renderSpec,
      formats,
      wantImage,
      wantAudio,
    });
    return res.json({ success: true, data: out });
  } catch (e) {
    if (e?.code === 'REMIX_QUOTA_EXCEEDED') {
      return res.status(429).json({ success: false, error: 'REMIX_QUOTA_EXCEEDED' });
    }
    return res.status(500).json({ success: false, error: 'REMIX_FAILED' });
  }
});

r.get('/:renderId/remixes', async (req, res) => {
  const renderId = String(req.params?.renderId || '').trim();
  if (!renderId) return res.status(400).json({ success: false, error: 'INVALID_INPUT' });
  try {
    const list = await listRemixes({ uid: req.user.uid, renderId });
    return res.json({ success: true, data: list });
  } catch (e) {
    return res.status(500).json({ success: false, error: 'REMIX_LIST_FAILED' });
  }
});

// ---- Social image + caption ----
const SocialImageSchema = z.object({ studioId: z.string().min(3), renderSpec: z.any().optional() });
r.post('/social-image', async (req, res) => {
  const parsed = SocialImageSchema.safeParse(req.body || {});
  if (!parsed.success)
    return res
      .status(400)
      .json({ success: false, error: 'INVALID_INPUT', detail: parsed.error.flatten() });
  const { studioId, renderSpec } = parsed.data;
  try {
    const out = await generateSocialImage({ uid: req.user.uid, studioId, renderSpec });
    return res.json({ success: true, data: out });
  } catch (e) {
    if (e?.message === 'NEED_IMAGE_OR_VIDEO')
      return res.status(400).json({ success: false, error: 'IMAGE_OR_VIDEO_REQUIRED' });
    return res.status(500).json({ success: false, error: 'SOCIAL_IMAGE_FAILED' });
  }
});

const CaptionSchema = z.object({
  quoteId: z.string().optional(),
  styleId: z.string().optional(),
  text: z.string().min(4),
  tone: z.string().optional(),
});
r.post('/caption', async (req, res) => {
  const parsed = CaptionSchema.safeParse(req.body || {});
  if (!parsed.success)
    return res
      .status(400)
      .json({ success: false, error: 'INVALID_INPUT', detail: parsed.error.flatten() });
  const { quoteId, styleId, text, tone } = parsed.data;
  try {
    const out = await generateCaption({ uid: req.user.uid, quoteId, styleId, text, tone });
    return res.json({ success: true, data: out });
  } catch (e) {
    return res.status(500).json({ success: false, error: 'CAPTION_FAILED' });
  }
});

r.get('/:studioId', async (req, res) => {
  const studioId = String(req.params?.studioId || '').trim();
  if (!studioId)
    return res
      .status(400)
      .json({ success: false, error: 'INVALID_INPUT', message: 'studioId required' });
  try {
    const s = await getStudio({ uid: req.user.uid, studioId });
    if (!s) return res.status(404).json({ success: false, error: 'NOT_FOUND' });
    return res.json({ success: true, data: s });
  } catch (e) {
    return res.status(500).json({ success: false, error: 'STUDIO_GET_FAILED' });
  }
});

// ---- Management ----
r.get('/', async (req, res) => {
  try {
    const result = await listStudios({ uid: req.user.uid });
    // Backward compatibility: if result is array (old format), wrap it
    // New format: { sessions, truncated, note }
    if (Array.isArray(result)) {
      return res.json({ success: true, data: result });
    }
    // New format: maintain backward compatibility by keeping data as array
    return res.json({
      success: true,
      data: result.sessions, // Frontend expects resp.data to be array
      truncated: result.truncated,
      note: result.note,
    });
  } catch (e) {
    return res.status(500).json({ success: false, error: 'STUDIO_LIST_FAILED' });
  }
});

// Diagnostics
r.get('/_dump', (req, res) => {
  return res.json({ success: true, data: storeDump() });
});
r.get('/_get/:studioId', (req, res) => {
  const id = String(req.params?.studioId || '').trim();
  const s = storeGet(id);
  if (!s) return res.json({ success: false });
  return res.json({ success: true, data: s });
});

const ResumeSchema = z.object({ studioId: z.string().min(3) });
r.post('/resume', async (req, res) => {
  const parsed = ResumeSchema.safeParse(req.body || {});
  if (!parsed.success)
    return res
      .status(400)
      .json({ success: false, error: 'INVALID_INPUT', detail: parsed.error.flatten() });
  const { studioId } = parsed.data;
  try {
    const s = await getStudio({ uid: req.user.uid, studioId });
    if (!s) return res.status(404).json({ success: false, error: 'NOT_FOUND' });
    return res.json({ success: true, data: s });
  } catch (e) {
    return res.status(500).json({ success: false, error: 'STUDIO_RESUME_FAILED' });
  }
});

const DeleteSchema = z.object({ studioId: z.string().min(3) });
r.post('/delete', async (req, res) => {
  const parsed = DeleteSchema.safeParse(req.body || {});
  if (!parsed.success)
    return res
      .status(400)
      .json({ success: false, error: 'INVALID_INPUT', detail: parsed.error.flatten() });
  const { studioId } = parsed.data;
  try {
    const out = await deleteStudio({ uid: req.user.uid, studioId });
    return res.json({ success: true, data: out });
  } catch (e) {
    return res.status(500).json({ success: false, error: 'STUDIO_DELETE_FAILED' });
  }
});

export default r;
